"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_text_games_api_1 = require("discord-text-games-api");
class SampleSeedGame {
    constructor(args) {
    }
    initialize(saveBundle) {
        return Promise.resolve();
    }
    destroy(saveBundle) {
        return Promise.resolve();
    }
    onEvent(event) {
        if (event.type === discord_text_games_api_1.EventType.JOIN) {
            this.handleJoin(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.MESSAGE) {
            this.handleMessage(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.BUTTON_CLICK) {
            this.handleButtonClick(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.SELECT_CHANGE) {
            this.handleSelectChange(event);
        }
    }
    handleJoin(event) {
        this.discordApi.sendMessage(event.user.id, `Hello user <@${event.user.id}>`).then((messageDescriptor) => {
            console.log("join message delivered, message id = " + messageDescriptor.messageId);
        });
    }
    handleMessage(event) {
        if (event.text === "button") {
            this.discordApi.sendMessage(event.user.id, `<@${event.user.id}>'s message was:\n ${event.text}`, {
                components: [
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Primary,
                            label: "Test Button1",
                            custom_id: "button1"
                        }),
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Danger,
                            label: "Test Button2",
                            emoji: {
                                name: "⚔️"
                            },
                            custom_id: "button2"
                        })
                    ]),
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.SelectMenu({
                            custom_id: "select1",
                            placeholder: "Feel tree to pick something",
                            options: [
                                new discord_text_games_api_1.SelectOption({
                                    label: "option1",
                                    value: "1",
                                    description: "nobody knows what this mean"
                                }),
                                new discord_text_games_api_1.SelectOption({
                                    label: "option2",
                                    value: "2"
                                })
                            ]
                        })
                    ]),
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Primary,
                            label: "Test Button3, row3",
                            custom_id: "button3"
                        })
                    ])
                ]
            });
        }
    }
    handleButtonClick(event) {
        this.discordApi.setControlEnabled(event.channelId, event.messageId, event.buttonId, false);
    }
    handleSelectChange(event) {
        this.discordApi.setControlEnabled(event.channelId, event.messageId, event.selectId, false);
    }
}
exports.default = SampleSeedGame;
//# sourceMappingURL=app.js.map