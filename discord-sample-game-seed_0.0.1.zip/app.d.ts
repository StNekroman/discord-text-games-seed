import { DiscordApi, GameEvent, GamePluginEntryPoint, Serializable } from "discord-text-games-api";
export default class SampleSeedGame implements GamePluginEntryPoint {
    discordApi: DiscordApi;
    constructor(args?: string);
    initialize(saveBundle?: Serializable): Promise<unknown>;
    destroy(saveBundle: Serializable): Promise<void>;
    onEvent(event: GameEvent): void;
    private handleJoin;
    private handleMessage;
    private handleButtonClick;
    private handleSelectChange;
}
