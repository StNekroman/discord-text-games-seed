import { DiscordApi, GameEvent, GamePluginEntryPoint } from "discord-text-games-api";
export default class SampleSeedGame implements GamePluginEntryPoint<void> {
    discordApi: DiscordApi;
    constructor(args?: string);
    initialize(): Promise<void>;
    destroy(): Promise<void>;
    onEvent(event: GameEvent): void;
    private handleJoin;
    private handleMessage;
    private handleButtonClick;
    private handleSelectChange;
}
