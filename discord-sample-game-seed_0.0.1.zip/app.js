"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const discord_text_games_api_1 = require("discord-text-games-api");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
class SampleSeedGame {
    constructor(args) {
    }
    initialize() {
        return Promise.resolve();
    }
    destroy() {
        return Promise.resolve();
    }
    onEvent(event) {
        if (event.type === discord_text_games_api_1.EventType.JOIN) {
            this.handleJoin(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.MESSAGE) {
            this.handleMessage(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.BUTTON_CLICK) {
            this.handleButtonClick(event);
        }
        else if (event.type === discord_text_games_api_1.EventType.SELECT_CHANGE) {
            this.handleSelectChange(event);
        }
    }
    handleJoin(event) {
        this.discordApi.sendMessageToUser(event.user.id, `Hello user <@${event.user.id}>`).then((messageDescriptor) => {
            console.log("join message delivered, message id = " + messageDescriptor.messageId);
        });
    }
    handleMessage(event) {
        console.log(event);
        event.attachments?.map(attachment => {
            return fs_1.default.promises.readFile(attachment).then(buffer => {
                const filename = path_1.default.parse(attachment).base;
                return Promise.all([
                    fs_1.default.promises.rm(attachment),
                    this.discordApi.sendMessageToUser(event.user.id, `Attachment received. Content of the file ${filename} is:\n` + "```" + buffer + "```")
                ]);
            });
        });
        if (event.text === "button") {
            this.discordApi.sendMessageToUser(event.user.id, `<@${event.user.id}>'s message was:\n ${event.text}`, {
                components: [
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Primary,
                            label: "Click to disable",
                            custom_id: "button1"
                        }),
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Danger,
                            label: "Click to disable",
                            emoji: {
                                name: "⚔️"
                            },
                            custom_id: "button2"
                        })
                    ]),
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.SelectMenu({
                            custom_id: "select1",
                            placeholder: "Feel tree to pick something",
                            options: [
                                new discord_text_games_api_1.SelectOption({
                                    label: "option1",
                                    value: "1",
                                    description: "nobody knows what this mean"
                                }),
                                new discord_text_games_api_1.SelectOption({
                                    label: "option2",
                                    value: "2"
                                })
                            ]
                        })
                    ]),
                    new discord_text_games_api_1.ActionRow([
                        new discord_text_games_api_1.Button({
                            style: discord_text_games_api_1.ButtonStyle.Primary,
                            label: "Submit image",
                            custom_id: "button3"
                        })
                    ])
                ]
            });
        }
    }
    handleButtonClick(event) {
        if (event.buttonId === "button3") {
            if (fs_1.default.existsSync("%gameDefDir%/sample.png")) {
                this.discordApi.sendMessageToUser(event.user.id, "image", {
                    files: ["%gameDefDir%/sample.png"]
                });
            }
            else {
                console.log("file not exists");
            }
        }
        else {
            this.discordApi.setControlEnabled(event.channelId, event.messageId, event.buttonId, false);
        }
    }
    handleSelectChange(event) {
        this.discordApi.setControlEnabled(event.channelId, event.messageId, event.selectId, false);
    }
}
exports.default = SampleSeedGame;
//# sourceMappingURL=app.js.map